package com.lolita.plugin;

/**
 * Created by quinn on 27/06/2017.
 */

public class LolitaExtension {
    def on = "false"
    def global = "false"
}
